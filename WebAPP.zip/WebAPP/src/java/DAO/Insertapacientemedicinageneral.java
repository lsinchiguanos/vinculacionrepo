 
package DAO;
import BD.conexion;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Insertapacientemedicinageneral {
     String sql = "";
    ResultSet rs = null;
    conexion cn = new conexion();
    private String sql_command = "";
    private PreparedStatement pst = null; 
}
